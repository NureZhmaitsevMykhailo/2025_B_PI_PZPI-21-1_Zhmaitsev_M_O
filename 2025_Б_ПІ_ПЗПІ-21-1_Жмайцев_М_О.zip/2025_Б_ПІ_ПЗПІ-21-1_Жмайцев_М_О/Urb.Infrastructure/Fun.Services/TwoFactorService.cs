﻿using Fun.Application.Fun.IServices;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Urb.Domain.Urb.Models;

namespace Fun.Infrastructure.Fun.Services
{
    public class TwoFactorService : ITwoFactorService
    {
        private readonly UserManager<User> _userManager;
        private readonly IEmailSender _emailSender;
        private readonly IUserService _userService;

        public TwoFactorService(UserManager<User> userManager, IEmailSender emailSender, IUserService userService)
        {
            _userManager = userManager;
            _emailSender = emailSender;
            _userService = userService;
        }

        public async Task<bool> IsTwoFactorEnabledAsync()
        {
            var currentUser = await _userService.GetMy();
            var user = await _userManager.FindByIdAsync(currentUser.ToString());
            return user?.TwoFactorEnabled ?? false;
        }

        public async Task SendTwoFactorCodeAsync()
        {
            var currentUser = await _userService.GetMy();
            var user = await _userManager.FindByIdAsync(currentUser.ToString());
            if (user == null) throw new Exception("User not found");

            var token = await _userManager.GenerateTwoFactorTokenAsync(user, TokenOptions.DefaultEmailProvider);
            await _emailSender.SendAsync(user.Email, "Your 2FA Code", $"Your code is: {token}");
        }

        public async Task<bool> VerifyTwoFactorCodeAsync(string code)
        {
            var currentUser = await _userService.GetMy();
            var user = await _userManager.FindByIdAsync(currentUser.ToString());
            if (user == null) return false;

            var isValid = await _userManager.VerifyTwoFactorTokenAsync(user, TokenOptions.DefaultEmailProvider, code);

            if (isValid)
            {
                user.TwoFactorEnabled = true;
                await _userManager.UpdateAsync(user);
            }

            return isValid;
        }
    }
}
