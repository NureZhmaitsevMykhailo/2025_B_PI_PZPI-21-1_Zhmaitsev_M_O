﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Fun.Application.Fun.IServices;

namespace Fun.Infrastructure.Fun.Services
{
    public class SmtpEmailSender : IEmailSender
    {
        private readonly SmtpClient _client;
        private readonly IConfiguration _config;

        public SmtpEmailSender(IConfiguration config)
        {
            _config = config;
            _client = new SmtpClient
            {
                Host = _config["Email:SmtpHost"],
                Port = int.Parse(_config["Email:SmtpPort"]),
                EnableSsl = true,
                Credentials = new NetworkCredential(
                    _config["Email:Username"],
                    _config["Email:Password"]
                )
            };
        }

        public async Task SendAsync(string to, string subject, string body)
        {
            var message = new MailMessage("noreply@yourapp.com", to, subject, body);
            await _client.SendMailAsync(message);
        }
    }
}
