﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Application.Fun.IServices
{
    public interface ITwoFactorService
    {
        Task<bool> IsTwoFactorEnabledAsync();
        Task SendTwoFactorCodeAsync();
        Task<bool> VerifyTwoFactorCodeAsync(string code);
    }
}
