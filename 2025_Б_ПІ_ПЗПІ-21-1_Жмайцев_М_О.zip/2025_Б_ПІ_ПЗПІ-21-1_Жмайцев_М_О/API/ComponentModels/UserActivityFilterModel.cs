﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Application.ComponentModels
{
    public class UserActivityFilterModel
    {
        public int? UserId { get; set; }
        public string? Email { get; set; }
        public decimal? MinTotalDonated { get; set; }
        public int? MinDonationCount { get; set; }
        public bool SortDesc { get; set; } = true;
    }
}
