﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Application.ResponseModels
{
    public class UserActivityResponseModel
    {
        public int UserId { get; set; }
        public string Email { get; set; } = null!;
        public decimal TotalDonated { get; set; }
        public int DonationCount { get; set; }
    }
}
