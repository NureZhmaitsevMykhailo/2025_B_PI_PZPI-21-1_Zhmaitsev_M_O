﻿using Fun.Domain.Fun.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fun.Application.ResponseModels
{
    public class SubscribeResponseModel
    {
        public int Id { get; set; }
        public int InitiativeId { get; set; }
        public InitiativeSummaryModel Initiative { get; set; } = null!;
        public DateTime SubscribedAt { get; set; }
    }
}
