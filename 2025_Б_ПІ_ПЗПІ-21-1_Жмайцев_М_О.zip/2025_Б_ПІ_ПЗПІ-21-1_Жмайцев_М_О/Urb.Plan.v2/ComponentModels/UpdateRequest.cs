﻿namespace Urb.Plan.v2.ComponentModels
{
    public class UpdateRequest
    {
    }
}
