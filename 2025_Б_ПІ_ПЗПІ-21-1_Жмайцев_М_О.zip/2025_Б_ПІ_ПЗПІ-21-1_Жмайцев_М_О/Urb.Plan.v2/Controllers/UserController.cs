﻿
using AutoMapper;
using Fun.Application.ComponentModels;
using Fun.Application.Fun.IServices;
using Fun.Application.IComponentModels;
using Fun.Application.IControllers;
using Fun.Application.ResponseModels;
using Fun.Domain.Fun.Models;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using Urb.Application.App.Settings;
using Urb.Domain.Urb.Models;



namespace Urb.Plan.v2.Controllers
{
    [Route("api/[controller]")]
    [AllowAnonymous]
    [ApiController]
    public class UserController : ControllerBase, IUserController
    {
        private IUserService _userService;
        private ITokenService _jwtService;
        private IMapper _mapper;
        private AppSettings _appSettings;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly SignInManager<User> _signInManager;
        private readonly IMonitoringService _monitoring;
        public UserController(
            IUserService userService,
            IMapper mapper,
            IOptions<AppSettings> appSettings,
            IHttpContextAccessor httpContextAccessor,
            SignInManager<User> signInManager,
            ITokenService jwtService,
            IMonitoringService monitoring
            )
        {
            _jwtService = jwtService;
            _userService = userService;
            _mapper = mapper;
            _appSettings = appSettings.Value;
            _httpContextAccessor = httpContextAccessor;
            _signInManager = signInManager;
            _monitoring = monitoring;
        }

        [Route("Register")]
        [AllowAnonymous]
        [HttpPost]
        public async Task<object> Register([FromBody] UserRegisterModel userRegisterModel)
        {
            var result = await _userService.Register(userRegisterModel);
            if (result is IdentityResult identityResult)
            {
                if (identityResult.Succeeded)
                {
                    return Ok("User registered successfully.");
                }
                else
                {
                    var errors = identityResult.Errors.Select(e => e.Description);
                    return BadRequest(new { Errors = errors });
                }
            }

            if (result?.GetType().GetProperty("Error")?.GetValue(result) is string errorDetail)
            {
                return BadRequest(new { Error = errorDetail });
            }

            if (result?.GetType().GetProperty("Message")?.GetValue(result) is string message)
            {
                return BadRequest(new { Message = message });
            }

            return BadRequest("Unknown error occurred.");
        }

            [AllowAnonymous]
            [HttpPost("authenticate")]
            public async Task<IActionResult> Authenticate(UserAuthenticateModel model)
            {
                var response = await _userService.AuthenticateUser(model);

                if (response is BadRequestObjectResult badRequestResult)
                {
                    return BadRequest(badRequestResult.Value);
                }

                if (response is OkObjectResult okResponse)
                {
                    return Ok(okResponse.Value);
                }

                return BadRequest("An unknown error occurred.");
            }

            [HttpGet("UserCheck")]
            [Authorize]
            public ActionResult<string> GetMyName()
            {
                var user = User.FindFirstValue(ClaimTypes.Email);
                return user;
            }

            [HttpGet("GetUser")]
            [Authorize]
            public IActionResult Get()
            {
                var emailClaim = User.Claims.First(c => c.Type == ClaimTypes.Email).Value;

                if (emailClaim != null)
                {
                    return Ok(new { Email = emailClaim });
                }
                else
                {
                    return NotFound("Email not found in claims.");
                }
            }

            [HttpGet("Profile")]
            [Authorize] 
            public async Task<IActionResult> GetProfile()
            {
                var profileResponse = await _userService.GetMyProfileAsyncBase64();
                return Ok(profileResponse);
            }

            [HttpPut("EditUserProfile")]
            [Authorize]
            public async Task<ActionResult<UserProfileResponseModel>> UpdateMyProfile(
            [FromForm] UserProfileComponentModel model)
            {
                var updated = await _userService.UpdateProfileAsync(model);
                return Ok(updated);
            }
           
            [HttpGet("/admin/userFilter")]
        public async Task<IActionResult> GetUsersActivity([FromQuery] UserActivityFilterModel filter)
        {
            var list = await _monitoring.GetUserActivityAsync(filter);

            var sorted = filter.SortDesc
                ? list.OrderByDescending(x => x.TotalDonated)
                : list.OrderBy(x => x.TotalDonated);

            return Ok(sorted);
        }

        [HttpGet("GetUserSettings")]
        [Authorize]
        public async Task<ActionResult<NotificationSetting>> GetSettings()
        {
            var settings = await _userService.GetMySettingsAsync();
            return Ok(settings);
        }

        [HttpPut("UpdateUserSettings")]
        [Authorize]
        public async Task<ActionResult<NotificationSetting>> Update([FromBody] NotificationSettingUpdateModel model)
        {
            var updated = await _userService.UpdateAsync(model);
            return Ok(updated);
        }






        [HttpGet("ExternalLog")]
        public IActionResult ExternalLogin(string returnUrl = "/")
        {
            var props = _userService.GetAuthenticationProperties(returnUrl);

            return Challenge(props, GoogleDefaults.AuthenticationScheme);
        }


        [HttpGet("ExternalLoginCallback")]
        public async Task<IActionResult> ExternalLoginCallback(string returnUrl = "/")
        {
            var info = await _signInManager.GetExternalLoginInfoAsync();
            if (info == null)
                return BadRequest("Cannot load external login info.");

            User domainUser = await _userService.HandleCallbackAsync();

            var authModel = new UserAuthenticateModel
            {
                Email = domainUser.Email,
                Password = null   
            };
            string jwt = _jwtService.GenerateToken(authModel);
            return Ok(new { /*token = jwt,*/ returnUrl });
        }


    }
} 
