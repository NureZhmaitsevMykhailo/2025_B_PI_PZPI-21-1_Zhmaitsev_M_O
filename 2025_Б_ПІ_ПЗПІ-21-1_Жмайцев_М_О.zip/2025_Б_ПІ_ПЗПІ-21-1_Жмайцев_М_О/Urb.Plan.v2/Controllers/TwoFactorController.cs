﻿using Fun.Application.Fun.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Fun.Plan.v2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TwoFactorController : ControllerBase
    {
        private readonly ITwoFactorService _twoFactorService;

        public TwoFactorController(ITwoFactorService twoFactorService)
        {
            _twoFactorService = twoFactorService;
        }

        [HttpGet("has-2fa")]
        [Authorize]
        public async Task<IActionResult> HasTwoFactor()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var result = await _twoFactorService.IsTwoFactorEnabledAsync();
            return Ok(result);
        }

        //[HttpPost("enable-2fa")]
        //[Authorize]
        //public async Task<IActionResult> EnableTwoFactor()
        //{
        //    var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    await _twoFactorService.EnableTwoFactorAsync();
        //    return Ok("2FA enabled");
        //}

        [HttpPost("send-2fa-code")]
        [Authorize]
        public async Task<IActionResult> SendTwoFactorCode()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            await _twoFactorService.SendTwoFactorCodeAsync();
            return Ok("Code sent");
        }

        [HttpPost("verify-2fa")]
        public async Task<IActionResult> VerifyTwoFactorCode([FromBody] TwoFactorVerifyRequest request)
        {
            var success = await _twoFactorService.VerifyTwoFactorCodeAsync(request.Code);
            if (!success) return Unauthorized("Invalid 2FA code");

            return Ok("2FA verification successful"); // або повертай JWT
        }
    }
    public class TwoFactorVerifyRequest
    {
        public string Code { get; set; }
    }
}
